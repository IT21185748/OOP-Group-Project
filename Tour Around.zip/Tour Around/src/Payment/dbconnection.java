 
package Payment;


import customer.*;
import java.sql.Connection;
import java.sql.DriverManager;

/**
 *
 * @author just
 */
public class dbconnection {
    private static String url = "jdbc:mysql://localhost:3306/tour_around";
    private static String username = "root";
    private static String pass = "ashan1234";
    private static Connection con ;
    static Connection connection(){
        try{
            Class.forName("com.mysql.cj.jdbc.Driver");
             con = (Connection) DriverManager.getConnection(url,username,pass);
            return con;

        }
        catch(Exception e){
            System.out.print(e);
            return null;
        }
    }
}
